# TroykaIMU

Arduino library to interface with the [Amperka IMU 10-DOF Sensor](https://amperka.ru/product/troyka-imu-10-dof).
